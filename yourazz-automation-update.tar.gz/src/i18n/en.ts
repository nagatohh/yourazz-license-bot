export const en: Record<string, string> = {
  // Panel
  "panel.title": "🚀 Yourazz License Manager",
  "panel.description": "Buy, manage and renew your seller license automatically.",
  "panel.features": "• Secure payment via Stripe\n• Automatic role assignment\n• Easy renewal\n• Support available",
  "panel.btnPayment": "💳 Payment",
  "panel.btnLanguage": "🌍 Language",
  "panel.btnHelp": "❓ Help",

  // Payment
  "payment.title": "🏷️ Seller License — Yourazz",
  "payment.description": "Become a certified seller on Yourazz.",
  "payment.price": "€25.00/month",
  "payment.features": "✓ Full seller access\n✓ Unlimited products\n✓ 30-day license\n✓ Priority support",
  "payment.btn": "💳 Pay €25",
  "payment.footer": "🔒 Secure payment by Stripe",
  "payment.stripeNotConfigured": "⚠️ Payment is not yet configured. Contact an administrator.",

  // Help
  "help.title": "❓ How does it work?",
  "help.description": "**1.** Click 💳 Payment\n**2.** Pay via Stripe (secure card)\n**3.** Wait for automatic validation\n**4.** Your seller role is assigned!\n**5.** Renew easily before expiration",
  "help.commands": "**Useful commands:**\n`/licence statut` — View your license\n`/licence renouveler` — Renew\n`/licence aide` — Full help",

  // Language
  "language.title": "🌍 Choose language",
  "language.description": "Select your preferred language.",
  "language.changed": "✅ Language changed to **English**",

  // Animation
  "animation.verifying": "Verifying payment...",
  "animation.pleaseWait": "Please wait...",
  "animation.activating": "Activating license...",
  "animation.almostDone": "Almost done...",
  "animation.assigningRole": "Assigning role...",
  "animation.finalStep": "Final step...",
  "animation.success": "Payment validated!",
  "animation.welcome": "Welcome to **Yourazz Seller** 🎉",
  "animation.licenseActive": "License activated",
  "animation.roleAssigned": "Seller role assigned",
  "animation.accessUnlocked": "Access unlocked",
  "animation.expiration": "Expiration:",

  // Status
  "status.active": "✅ Active",
  "status.expired": "❌ Expired",
  "status.suspended": "🔴 Suspended",
  "status.noLicense": "You don't have an active license.\nClick 💳 Payment to get one.",

  // Errors
  "error.generic": "❌ An error occurred.",
  "error.noPermission": "❌ You don't have permission.",

  // Owner Manager
  "owner.accessDenied": "Access Denied",
  "owner.accessDeniedDesc": "You don't have the Owner role.\nContact an admin to be added.",
  "owner.footer": "-# 👑 Yourazz Owner Manager System",

  // Owner Dashboard
  "owner.dashboard.title": "## 📊 Dashboard — {username}",
  "owner.dashboard.score": "**Score:** {score} pts",
  "owner.dashboard.rank": "**Rank:** #{rank}",
  "owner.dashboard.teamTitle": "### 👥 Team",
  "owner.dashboard.teamStats": "Total: **{total}** • 🟢 Active: **{active}** • 🔴 Inactive: **{inactive}**",
  "owner.dashboard.monthlyTitle": "### 🎯 Monthly Goal",
  "owner.dashboard.nextTier": "**Next tier:** {emoji} {label} ({minRecruits} active recruits)",
  "owner.dashboard.maxTier": "🏆 **Maximum tier reached!**",

  // Owner Team
  "owner.team.title": "## 👥 My Team ({count})",
  "owner.team.empty": "Empty Team",
  "owner.team.emptyDesc": "You haven't recruited anyone yet.\nAsk an admin to assign recruits to you.",
  "owner.team.stats": "🟢 **{active}** active • 🔴 **{inactive}** inactive",
  "owner.team.sales": "{count} sales",

  // Owner Leaderboard
  "owner.leaderboard.title": "## 🏆 Owner Leaderboard",
  "owner.leaderboard.empty": "No Owners",
  "owner.leaderboard.emptyDesc": "No Owner has been registered yet.",
  "owner.leaderboard.entry": "{medal} <@{discordId}> — **{score} pts** • {emoji} {tier} • {active} active",

  // Owner Objectives
  "owner.objectives.title": "## 🎯 My Goals",
  "owner.objectives.monthly": "### 📅 Monthly",
  "owner.objectives.weekly": "### 📆 Weekly",
  "owner.objectives.none": "No active goals",
  "owner.objectives.tipsTitle": "### 💡 Tips",
  "owner.objectives.tip1": "▸ Recruit people who will stay active",
  "owner.objectives.tip2": "▸ Support your recruits during the first week",
  "owner.objectives.tip3": "▸ A member retained 30d = +100 pts bonus",

  // Owner Rewards
  "owner.rewards.title": "## 🎁 Owner Rewards",
  "owner.rewards.tierTitle": "### 🏅 Rewards by Tier",
  "owner.rewards.bronze": "🥉 **Bronze** (5 active recruits)\n▸ Exclusive Bronze Owner role\n▸ Owner category access",
  "owner.rewards.silver": "🥈 **Silver** (15 active recruits)\n▸ Private Silver channel\n▸ Server profile badge",
  "owner.rewards.gold": "🥇 **Gold** (30 active recruits)\n▸ Early access to features\n▸ Server visibility\n▸ Mentioned in announcements",
  "owner.rewards.diamond": "💎 **Diamond** (50 active recruits)\n▸ Exclusive premium perks\n▸ VIP Diamond lounge\n▸ Priority on decisions",
  "owner.rewards.legend": "🏆 **Legend** (100 active recruits)\n▸ Permanent Legend status\n▸ All rewards unlocked\n▸ Official Yourazz recognition",

  // Owner Help
  "owner.help.title": "## ❓ Help — Owner Manager",
  "owner.help.howTitle": "### 🔑 How it works",
  "owner.help.howDesc": "You are an **Owner** — a Yourazz recruiter/manager.\nYou recruit members, support them, and earn points based on their activity.",
  "owner.help.earnTitle": "### 📈 How to earn points",
  "owner.help.earnRecruit": "▸ New active recruit → **+{pts}**",
  "owner.help.earnActivity": "▸ Regular team activity → **+{pts}**",
  "owner.help.earnRetention": "▸ 30-day retention → **+{pts}**",
  "owner.help.earnSale": "▸ Member sale → **+{pts}**",
  "owner.help.noPointsTitle": "### ❌ What doesn't earn points",
  "owner.help.noPointsDesc": "▸ Inactive recruits\n▸ Members who don't participate\n▸ Recruits who leave quickly",
  "owner.help.costTitle": "### ⚠️ What costs points",
  "owner.help.costSanction": "▸ Member sanctioned → **{pts}**",
  "owner.help.costLeft": "▸ Member left → **{pts}**",
  "owner.help.commandsTitle": "### 📋 Commands",
  "owner.help.commandsList": "▸ `/owner dashboard` — Dashboard\n▸ `/owner team` — Team\n▸ `/owner stats` — Statistics\n▸ `/owner recruits` — Recent recruits",
};
