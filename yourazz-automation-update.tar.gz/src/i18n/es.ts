export const es: Record<string, string> = {
  // Panel
  "panel.title": "🚀 Yourazz License Manager",
  "panel.description": "Compra, gestiona y renueva tu licencia de vendedor automáticamente.",
  "panel.features": "• Pago seguro con Stripe\n• Asignación automática de rol\n• Renovación simplificada\n• Soporte disponible",
  "panel.btnPayment": "💳 Pago",
  "panel.btnLanguage": "🌍 Idioma",
  "panel.btnHelp": "❓ Ayuda",

  // Payment
  "payment.title": "🏷️ Licencia Vendedor — Yourazz",
  "payment.description": "Conviértete en vendedor certificado en Yourazz.",
  "payment.price": "25,00 €/mes",
  "payment.features": "✓ Acceso completo de vendedor\n✓ Productos ilimitados\n✓ Licencia 30 días\n✓ Soporte prioritario",
  "payment.btn": "💳 Pagar 25€",
  "payment.footer": "🔒 Pago seguro con Stripe",
  "payment.stripeNotConfigured": "⚠️ El pago aún no está configurado. Contacta a un administrador.",

  // Help
  "help.title": "❓ ¿Cómo funciona?",
  "help.description": "**1.** Haz clic en 💳 Pago\n**2.** Paga con Stripe (tarjeta segura)\n**3.** Espera la validación automática\n**4.** ¡Tu rol de vendedor es asignado!\n**5.** Renueva fácilmente antes del vencimiento",
  "help.commands": "**Comandos útiles:**\n`/licence statut` — Ver tu licencia\n`/licence renouveler` — Renovar\n`/licence aide` — Ayuda completa",

  // Language
  "language.title": "🌍 Elegir idioma",
  "language.description": "Selecciona tu idioma preferido.",
  "language.changed": "✅ Idioma cambiado a **Español**",

  // Animation
  "animation.verifying": "Verificando pago...",
  "animation.pleaseWait": "Por favor espera...",
  "animation.activating": "Activando licencia...",
  "animation.almostDone": "Casi listo...",
  "animation.assigningRole": "Asignando rol...",
  "animation.finalStep": "Último paso...",
  "animation.success": "¡Pago validado!",
  "animation.welcome": "Bienvenido a **Yourazz Seller** 🎉",
  "animation.licenseActive": "Licencia activada",
  "animation.roleAssigned": "Rol de vendedor asignado",
  "animation.accessUnlocked": "Acceso desbloqueado",
  "animation.expiration": "Vencimiento:",

  // Status
  "status.active": "✅ Activa",
  "status.expired": "❌ Expirada",
  "status.suspended": "🔴 Suspendida",
  "status.noLicense": "No tienes una licencia activa.\nHaz clic en 💳 Pago para obtener una.",

  // Errors
  "error.generic": "❌ Ocurrió un error.",
  "error.noPermission": "❌ No tienes permiso.",

  // Owner Manager
  "owner.accessDenied": "Acceso denegado",
  "owner.accessDeniedDesc": "No tienes el rol Owner.\nContacta a un admin para ser añadido.",
  "owner.footer": "-# 👑 Yourazz Owner Manager System",

  // Owner Dashboard
  "owner.dashboard.title": "## 📊 Dashboard — {username}",
  "owner.dashboard.score": "**Puntuación:** {score} pts",
  "owner.dashboard.rank": "**Ranking:** #{rank}",
  "owner.dashboard.teamTitle": "### 👥 Equipo",
  "owner.dashboard.teamStats": "Total: **{total}** • 🟢 Activos: **{active}** • 🔴 Inactivos: **{inactive}**",
  "owner.dashboard.monthlyTitle": "### 🎯 Objetivo mensual",
  "owner.dashboard.nextTier": "**Próximo tier:** {emoji} {label} ({minRecruits} reclutas activos)",
  "owner.dashboard.maxTier": "🏆 **¡Tier máximo alcanzado!**",

  // Owner Team
  "owner.team.title": "## 👥 Mi Equipo ({count})",
  "owner.team.empty": "Equipo vacío",
  "owner.team.emptyDesc": "Aún no has reclutado a nadie.\nPide a un admin que te asigne reclutas.",
  "owner.team.stats": "🟢 **{active}** activos • 🔴 **{inactive}** inactivos",
  "owner.team.sales": "{count} ventas",

  // Owner Leaderboard
  "owner.leaderboard.title": "## 🏆 Clasificación Owners",
  "owner.leaderboard.empty": "Sin Owners",
  "owner.leaderboard.emptyDesc": "Ningún Owner está registrado aún.",
  "owner.leaderboard.entry": "{medal} <@{discordId}> — **{score} pts** • {emoji} {tier} • {active} activos",

  // Owner Objectives
  "owner.objectives.title": "## 🎯 Mis Objetivos",
  "owner.objectives.monthly": "### 📅 Mensuales",
  "owner.objectives.weekly": "### 📆 Semanales",
  "owner.objectives.none": "Sin objetivos activos",
  "owner.objectives.tipsTitle": "### 💡 Consejos",
  "owner.objectives.tip1": "▸ Recluta perfiles que se mantendrán activos",
  "owner.objectives.tip2": "▸ Acompaña a tus reclutas la primera semana",
  "owner.objectives.tip3": "▸ Un miembro retenido 30d = +100 pts bonus",

  // Owner Rewards
  "owner.rewards.title": "## 🎁 Recompensas Owner",
  "owner.rewards.tierTitle": "### 🏅 Recompensas por Tier",
  "owner.rewards.bronze": "🥉 **Bronze** (5 reclutas activos)\n▸ Rol exclusivo Bronze Owner\n▸ Acceso categoría Owner",
  "owner.rewards.silver": "🥈 **Silver** (15 reclutas activos)\n▸ Canal privado Silver\n▸ Badge perfil servidor",
  "owner.rewards.gold": "🥇 **Gold** (30 reclutas activos)\n▸ Acceso anticipado a features\n▸ Visibilidad en servidor\n▸ Mención en anuncios",
  "owner.rewards.diamond": "💎 **Diamond** (50 reclutas activos)\n▸ Ventajas exclusivas premium\n▸ Salón VIP Diamond\n▸ Prioridad en decisiones",
  "owner.rewards.legend": "🏆 **Legend** (100 reclutas activos)\n▸ Estatus permanente Legend\n▸ Todas las recompensas\n▸ Reconocimiento oficial Yourazz",

  // Owner Help
  "owner.help.title": "## ❓ Ayuda — Owner Manager",
  "owner.help.howTitle": "### 🔑 Cómo funciona",
  "owner.help.howDesc": "Eres un **Owner** — un reclutador/manager Yourazz.\nReclutas miembros, los acompañas y ganas puntos según su actividad.",
  "owner.help.earnTitle": "### 📈 Cómo ganar puntos",
  "owner.help.earnRecruit": "▸ Nuevo recluta activo → **+{pts}**",
  "owner.help.earnActivity": "▸ Actividad regular del equipo → **+{pts}**",
  "owner.help.earnRetention": "▸ Retención 30 días → **+{pts}**",
  "owner.help.earnSale": "▸ Venta de un miembro → **+{pts}**",
  "owner.help.noPointsTitle": "### ❌ Lo que no da puntos",
  "owner.help.noPointsDesc": "▸ Reclutas inactivos\n▸ Miembros que no participan\n▸ Reclutas que se van rápido",
  "owner.help.costTitle": "### ⚠️ Lo que cuesta puntos",
  "owner.help.costSanction": "▸ Sanción de un miembro → **{pts}**",
  "owner.help.costLeft": "▸ Miembro que se va → **{pts}**",
  "owner.help.commandsTitle": "### 📋 Comandos",
  "owner.help.commandsList": "▸ `/owner dashboard` — Panel de control\n▸ `/owner team` — Equipo\n▸ `/owner stats` — Estadísticas\n▸ `/owner recruits` — Reclutas recientes",
};
